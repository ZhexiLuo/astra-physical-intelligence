# Deskclean: video to robot simulation

A source-grounded tabletop cleaning scene, a commercial TIAGo++ robot, an audited
MuJoCo rollout, and three Blender camera views. The supplied six-second video is
interpreted into a scripted bimanual cleaning skill. Tool dimensions are estimated;
tools start grasped, and bristles use a rigid contact proxy.

The robot retains the Menagerie geometry, joints, and force limits. Six free bodies
are moved by contact. A separate inverse-kinematics state supplies joint targets;
the simulation advances through actuator controls and `mj_step`.

## Run

Use Python 3.12, MuJoCo 3.4.0, and Blender 4.2.1. Install `requirements.txt` into an
isolated environment. The reproduction archive includes the pinned robot assets,
the input scene specification, audit tests, and the verified trajectory.
Run the installation commands from the extracted project directory.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export BLENDER=/path/to/blender
export CUDA_VISIBLE_DEVICES=0
bash scripts/reproduce.sh
```

Rendering requires an NVIDIA CUDA device. A Mac can inspect the self-contained
`agent/out/deskclean.blend` without rerunning the GPU render.
Set `BLENDER` to an absolute executable path. FFmpeg is supplied by the installed
`imageio-ffmpeg` package; `FFMPEG` can optionally name another executable on `PATH`
or an absolute path.

Each invocation creates `agent/out/reproductions/run-XXXXXXXX/` and copies the
source, required tests, robot assets, and input specification there. All new
simulation, render, and log files are written inside that directory. The script
prints its absolute path before execution and prints the final video, Blender,
and log paths on completion. The archive's verified reference run stays intact.

## Layout

- `src/`: scene construction, control, USD export, Blender setup, and rendering.
- `scripts/reproduce.sh`: commands for the complete pipeline.
- `thirdparty/mujoco_menagerie/pal_tiago_dual/`: original robot model and license.
- `agent/out/simulation/`: MJCF, states, controls, contacts, and audited metrics.
- `agent/out/deskclean.blend`: baked rigid-body animation and three cameras.
- `agent/log/`: complete command output.
- `agent/out/reproductions/run-XXXXXXXX/`: an isolated rerun, with its own `agent/out/` and `agent/log/`.
- `agent/doc/workflow-zh.md`: detailed Chinese workflow and modeling decisions.

## Provenance

TIAGo++ is a PAL Robotics product. Robot assets come from
[MuJoCo Menagerie](https://github.com/google-deepmind/mujoco_menagerie/tree/8161bba264d7fa7c99ca301e91e7fb44737676ad/pal_tiago_dual),
revision `8161bba264d7fa7c99ca301e91e7fb44737676ad`, under Apache-2.0.
The generated task MJCF fixes the base and adds the table, tools, and free blocks.
Original model license and notices are retained in the archive.
