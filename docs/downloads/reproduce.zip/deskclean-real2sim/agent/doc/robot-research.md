# 双臂轮式夹爪机器人模型核实

核实日期：2026-09-09。目标：真实市售机器人，复现左手持簸箕、右手用刷子扫彩色方块；直接使用公开机器人资产，MuJoCo CPU 仿真，Blender 渲染。

## 决定与验证

选择 **PAL Robotics TIAGo++ 双臂全向轮式底座版本**，使用 Google DeepMind MuJoCo Menagerie 的 `pal_tiago_dual`。该模型由 PAL 官方公开 URDF 转换；整机有真实产品来源，无需拼接自造机器人。产品配置支持双 7-DoF 臂和平行夹爪。[产品](https://pal-robotics.com/robot/tiago/)；[模型来源与转换说明](https://github.com/google-deepmind/mujoco_menagerie/blob/8161bba264d7fa7c99ca301e91e7fb44737676ad/pal_tiago_dual/README.md#L10-L30)。

已经完成：下载、逐文件 Git blob SHA-1 校验、复制至 rl-1、MuJoCo 3.4.0 CPU 加载、位置控制模式下 2500 步测试。5 秒仿真耗时 **0.148 秒**，状态有限、无数值警告，最终底座高度 −0.000059 m。该测试只证明模型加载及基础稳定运行，尚未验证扫入任务成功。

| 项目 | 已核实结果 |
|---|---|
| 上游 revision | `8161bba264d7fa7c99ca301e91e7fb44737676ad` |
| 模型目录 | 32 文件，7,832,153 bytes；加仓库根 README/LICENSE 共 34 文件，8,282,498 bytes |
| 直接入口 | `pal_tiago_dual/scene_position.xml` |
| 机器人入口 | `pal_tiago_dual/tiago_dual_position.xml`，包含 `tiago_dual.xml` |
| 规模 | nq=32，nv=31，nu=25，27 bodies，44 geoms，25 meshes |
| 视觉网格 | 编译后共 97,132 vertices、192,960 triangles |
| 控制 | 4 轮速度，1 躯干升降、2 头部、14 臂关节、4 手指位置控制 |
| 夹爪 | PAL 平行夹爪；模型每夹爪 2 个反向 slide，单指范围 0–0.045 m；成对输入相同值实现单标量开合 |
| 已用环境 | `/home/zhexi/miniconda3/envs/retargeting/bin/python`，MuJoCo 3.4.0 |

原示例 `scene_position.xml` 地面为 **z=−0.99 m**，机器人默认底座却为 z=0。新桌面场景须将地面设置为 z=0；验证只在内存中这样设置，未修改下载的第三方原文件。默认零位双臂向左右展开，需要 IK 设置桌面工作姿态。README 的最低版本声明为 2.2.2，但当前 MJCF 包含更新 actuator 参数，本文仅承诺已测的 3.4.0 环境。

## 控制与渲染接口

- 双臂关节：`arm_{left,right}_{1..7}_joint`；对应 actuator 后缀 `_position`。
- 夹爪关节：`gripper_{left,right}_{left,right}_finger_joint`；对应 actuator 后缀 `_position`。手指 ctrl 对称，单指 0–0.045 m。
- 躯干：`torso_lift_joint`，范围 0–0.35 m。
- 手腕参考 body：`arm_left_7_link` / `arm_right_7_link`。两侧局部朝向并不相同，工具 TCP 必须分别依据 FK 定义。
- 机器人模型含真实关节力限制；读取原模型，场景层配置控制目标即可。双臂工作区通过已有 SciPy `least_squares` 优化 MuJoCo FK，主仿真通过 actuator 和 `mj_step` 执行。
- Blender 可使用同一官方 STL；模型多处有负 mesh scale，直接导入 STL 后必须保留 MJCF mesh scale 和局部变换。更直接的视觉传递方式是导出 MuJoCo 编译后的 mesh vertices/faces 与逐帧 geom world pose，避免再次解释镜像与 mesh 主轴对齐。MuJoCo 编译会平移/旋转 mesh 并补偿 geom pose：[官方 mesh 文档](https://mujoco.readthedocs.io/en/stable/XMLreference.html#asset-mesh)。

## 候选对比

| 机型 | 原始来源、资产与许可 | 接入成本与结论 |
|---|---|---|
| Galaxea R1 Pro | [OpenGalaxea/GalaxeaManipSim](https://github.com/OpenGalaxea/GalaxeaManipSim/tree/abe7f5161eeaa150e6eaffdf443af5df7f23f356/galaxea_sim/assets/r1_pro)，官方 URDF+OBJ+STL，160 文件/79,404,053 bytes；Apache-2.0，保留 MIT NOTICE | 无原生 MJCF；官方仿真栈是 SAPIEN，另有 Isaac Sim 示例。需要导入、执行器和夹爪联动配置。本次不安装它的仿真栈，不下载全目录。 |
| Galaxea R1 | 同仓库 `galaxea_sim/assets/r1/`；182 文件/161,464,485 bytes；同许可 | 每臂 6-DoF，Pro 每臂 7-DoF。两者 URDF 两指各 0–0.05 m；机器人 URDF 把底盘轮关节固定，直接使用该文件并不等于已验证轮式移动动力学。 |
| TIAGo++ | [Menagerie MJCF](https://github.com/google-deepmind/mujoco_menagerie/tree/8161bba264d7fa7c99ca301e91e7fb44737676ad/pal_tiago_dual)，Apache-2.0；[PAL 原始 URDF](https://github.com/pal-robotics/tiago_dual_robot) | 已有控制器、碰撞和 meshes；体积小、CPU 直接运行，最终选择。 |
| Trossen Mobile ALOHA / Mobile AI | [旧 Mobile ALOHA 产品](https://www.trossenrobotics.com/aloha-mobile) 已标 discontinued；[当前 Mobile AI 产品](https://www.trossenrobotics.com/mobile-ai)；[厂商代码](https://github.com/Interbotix/aloha) | Menagerie 的 [ALOHA MJCF](https://github.com/google-deepmind/mujoco_menagerie/blob/main/aloha/README.md) 是桌面 ALOHA 2，BSD-3-Clause，不能将它直接宣称为完整市售轮式 Mobile ALOHA。厂商 ROS 资产需组合多个包，未验证完整移动版 MJCF；不作为快速首选。 |

R1 Pro 实物官方装箱表是 2×A2 机械臂和 2×G1 夹爪；官方硬件规格是单臂连夹爪 8 DoF、躯干 4 DoF、底盘 6 DoF，共 26 DoF。[装箱与硬件](https://docs.galaxea-ai.com/Guide/R1Pro/unboxing/R1Pro_Unbox_Startup_Guide/)；[规格](https://docs.galaxea-ai.com/Guide/R1Pro/hardware_introduction/R1Pro_Hardware_Introduction/)；[官方 Isaac Sim 指引](https://docs.galaxea-ai.com/Guide/R1Pro/isaacsim/r1pro_isaacsim_guide/)。数字模型中的两个手指关节不应被解释成实物两个独立夹爪控制自由度。

## Blog 与再分发

TIAGo++ 模型目录自己的 README 明确声明 Apache-2.0，不能用 Menagerie 仓库根的综合许可代替模型目录许可。[声明](https://github.com/google-deepmind/mujoco_menagerie/blob/8161bba264d7fa7c99ca301e91e7fb44737676ad/pal_tiago_dual/README.md#L32-L34)。Apache 第 2 节授予公开展示、衍生与再分发权；第 4 节要求分发许可、保留声明，并标注修改文件。[许可 §§2、4](https://github.com/google-deepmind/mujoco_menagerie/blob/8161bba264d7fa7c99ca301e91e7fb44737676ad/pal_tiago_dual/LICENSE#L66-L128)。因此 blog 渲染可注明“TIAGo++ by PAL Robotics; model adapted from MuJoCo Menagerie, Apache-2.0”，资产包保留本目录 LICENSE，并说明固定底座和工具装配等更改。

Galaxea 根 [LICENSE](https://github.com/OpenGalaxea/GalaxeaManipSim/blob/abe7f5161eeaa150e6eaffdf443af5df7f23f356/LICENSE) 明示 Copyright 2025 Galaxea、Apache-2.0；[NOTICE](https://github.com/OpenGalaxea/GalaxeaManipSim/blob/abe7f5161eeaa150e6eaffdf443af5df7f23f356/NOTICE) 保留部分来源的 MIT 许可。核实目录树未见另一个覆盖机器人资产的许可文件。

## 本地产物

- 模型：`/Users/zhexiluo/Documents/ChatGPT/gpt6-ultra-real2sim/agent/out/robot-research/mujoco_menagerie/pal_tiago_dual/`
- 远程模型：`/mnt2/zhexi/deskclean-real2sim/thirdparty/mujoco_menagerie/pal_tiago_dual/`
- 下载清单与 SHA：`agent/out/robot-research/tiago-manifest.json`、`galaxea-manifest.json`
- Galaxea 小型证据文件：`agent/out/robot-research/galaxea-metadata/`，仅 URDF、许可、pyproject，不含 meshes。
- 下载验证日志：`/Users/zhexiluo/Documents/ChatGPT/gpt6-ultra-real2sim/agent/log/robot-assets-download.log`
- CPU 验证日志：`/Users/zhexiluo/Documents/ChatGPT/gpt6-ultra-real2sim/agent/log/robot-mujoco-validation.log`
- 远程结构化结果：`/mnt2/zhexi/deskclean-real2sim/agent/log/robot-mujoco-validation.json`
