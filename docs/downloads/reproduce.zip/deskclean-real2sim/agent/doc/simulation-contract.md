# TIAGo++ 扫入仿真交付契约

## 执行与验证

远程项目：`/mnt2/zhexi/deskclean-real2sim`。依赖复用 `/home/zhexi/miniconda3/envs/retargeting/bin/python`（MuJoCo 3.4.0、NumPy、SciPy），未改该环境。

```bash
cd /mnt2/zhexi/deskclean-real2sim
/home/zhexi/miniconda3/envs/retargeting/bin/python -m src.simulation > agent/log/simulation.log 2>&1
/home/zhexi/miniconda3/envs/retargeting/bin/python -m unittest agent.test.simulation_contract > agent/log/simulation-audit.log 2>&1
```

第一条生成物理结果和原始指标。第二条独立审计已生成的结果，并将 `success`、`validity_checks`、`run_id` 写入 `metrics.json`；不重复规划或覆盖轨迹。只有审计通过的结果才带完整成功声明。

源文件职责：`src/robot_control.py` 的 `ArmKinematics.solve` 用独立 MuJoCo data 和 SciPy least_squares 求工具原点位姿，`tool_targets` 给出扫入、退刷、抬簸箕的连续目标；`src/simulation.py` 的 `build_scene` 组装官方机器人与桌面任务，`step_control` 只写 ctrl 并执行真实 `mj_step`，`run_simulation` 记录状态和接触，`replay_controls` 独立复现已保存控制序列。

## 物理约定与结果

- 机器人是固定底座的官方 TIAGo++ 数字模型；原有关节和执行器力限逐项与上游比较一致。规划腕部保留额外壳体余量，但不改变物理模型的关节限值。
- 工具已经预抓持，作为原夹爪腕部的固定子体。这是明确的任务起始条件，未模拟自主接近/抓取。夹爪手指保持夹持开度。
- 6 个 22 mm 方块全程为 freejoint。初始状态之后，主仿真不写对象 qpos、mocap 或外力；动作由机器人关节控制和接触推进。
- 刷毛用刚性碰撞代理。单目视频的尺寸来自估计，未声称度量标定。
- 最终规划整体平移 `[-0.06, -0.12, 0]` m；簸箕初始原点 `[0.60, -0.11, 0.731]`，刷子初始原点 `[0.60, -0.38, 0.732]`，台面 z=0.73。
- 簸箕底面 profile（局部 y/z）为 `[[-0.015,-0.001],[0,0.002],[0.23,0.009]]`，对应厚度 `[0,0.002,0.002]`。前缘与桌面齐平，其余底面不与桌面预穿插；视觉应使用相同 profile。
- 原先默认薄板软接触在独立单块测试中造成约 6.1 mm 穿透；任务接触时间常数设为 0.006 s 后，完整运行全程最大穿透为 **0.668 mm**，机器人自碰撞穿透为 **0**。详见 `agent/log/pan-contact-isolation.log`。
- 7.2 秒轨迹结束后，6 块的全部 8 个角点位于簸箕腔体中（底面接触容差 1 mm）；IK 工具原点最大误差 **0.232 mm**；独立控制重放 qpos 最大绝对误差 **0**。

## 输出与 schema

稳定输出目录：`agent/out/simulation/`。`simulation-test/` 为前一轮对照，不用于最终发布。

| 文件 | 内容 |
|---|---|
| `scene.xml` | 完整 MJCF；相对 meshdir；含 Apache 派生修改声明和上游 revision |
| `resolved-scene-spec.json` | 已解决的坐标、工具几何和物理假设；Blender 应以此为准 |
| `trajectory.npz` | 逐步状态、真实发送给 MuJoCo 的 ctrl、用于渲染的刚体与 geom 位姿 |
| `contacts.jsonl` | 每个接触的 time、bodies、geom_ids、distance、position、6D contact-frame force |
| `metrics.json` | 物理指标与独立测试产生的成功/有效性声明 |

`trajectory.npz` 的 `time/qpos/qvel` 有 3601 项，`ctrl` 有 3600 项。`ctrl[k]` 将状态 k 推进到 k+1；初始对象状态仅来自第 0 项。`frame_indices` 有 174 项，指向逐步状态数组；`body_xpos/body_xquat/geom_xpos/geom_xmat` 只按这些渲染帧保存。所有 body 四元数均为 **wxyz**；geom 旋转为 3×3 矩阵的行优先展开。`body_names/geom_names/actuator_names` 分别与对应模型数组同序。

工具刚体名称：`dustpan`、`brush`。方块刚体名称：`block_0` 至 `block_5`。MuJoCo 的工具代理可在 Blender 隐藏，用这些 body 的 world pose 挂载相同本地坐标系的视觉模型。接触 time 标记该次 `mj_step` 求解的积分前状态，故是步后 `data.time - dt`。

发布摘要映射：

| 发布字段 | 原始 metrics 字段 |
|---|---|
| success | `success` |
| collected | `blocks_in_dustpan` |
| total_blocks | `block_count` |
| duration_s | `duration` |
| max_penetration_m | `max_penetration_m.all` |
| contact_impulse_ns | `brush_block_normal_impulse_ns`，刷子-方块法向冲量 |
| run_id | `run_id` |

本次正确分类的接触数为 brush-block 4544、dustpan-block 10155；对应法向冲量分别为 0.6191124 N·s 和 1.8636634 N·s。`max_penetration_m` 还分别报告 `block_dustpan` 和 `robot_self`，避免用收集数量掩盖碰撞问题。

审查先检查正确性，再检查质量。独立 reviewer 验证了逐帧 qpos 重建与保存 body/geom pose 一致、角点矩阵顺序、接触时间约定，并指出工具接触计数漏筛 block 与绝对 meshdir；两项已修正。全部 5 项测试通过，未 git add/commit。
