import json
import os
import time
from pathlib import Path

import bpy


CONTROL = Path(os.environ["DESKCLEAN_CONTROL_DIR"])
COMMAND = CONTROL / "command.py"
STATUS = CONTROL / "status.json"
last_stamp = -1


def write_status(state: str, stamp: int) -> None:
    temporary = STATUS.with_suffix(".pending.json")
    temporary.write_text(json.dumps({
        "state": state,
        "command_mtime_ns": stamp,
        "updated_unix": time.time(),
        "blender_pid": os.getpid(),
    }, indent=2) + "\n")
    temporary.replace(STATUS)


def poll_command() -> float:
    global last_stamp
    stamp = COMMAND.stat().st_mtime_ns
    if stamp != last_stamp:
        last_stamp = stamp
        source = COMMAND.read_text()
        write_status("running", stamp)
        exec(compile(source, str(COMMAND), "exec"), {
            "bpy": bpy, "__name__": "__main__", "__file__": str(COMMAND)
        })
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
        write_status("done", stamp)
    return 0.5


write_status("ready", last_stamp)
bpy.app.timers.register(poll_command, first_interval=0.5, persistent=True)
