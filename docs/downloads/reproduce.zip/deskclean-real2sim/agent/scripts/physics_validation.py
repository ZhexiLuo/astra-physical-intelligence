import os

for variable in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ[variable] = "1"

import concurrent.futures
import hashlib
import json
import pathlib
import time
import xml.etree.ElementTree as ET

import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from src.simulation import task_metrics


ROOT = pathlib.Path(__file__).resolve().parents[2]
REFERENCE = ROOT / "agent/out/simulation"
OUTPUT = ROOT / "agent/out/validation"


def array_hash(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def condition_model(disable_contact: bool, friction_scale: float) -> mujoco.MjModel:
    root = ET.parse(REFERENCE / "scene.xml").getroot()
    compiler = root.find("compiler")
    compiler.set("meshdir", str((REFERENCE / compiler.get("meshdir")).resolve()))
    compiler.set("usethread", "false")
    if disable_contact:
        for index in range(6):
            ET.SubElement(root.find("contact"), "exclude", body1="brush",
                          body2=f"block_{index}")
    model = mujoco.MjModel.from_xml_string(ET.tostring(root, encoding="unicode"))
    for index in range(6):
        model.geom(f"block_{index}").friction[0] *= friction_scale
    return model


def body_pairs(model: mujoco.MjModel, data: mujoco.MjData) -> list[tuple]:
    return [tuple(sorted(model.body(model.geom_bodyid[g]).name
                         for g in [contact.geom1, contact.geom2]))
            for contact in data.contact]


def is_tool_block(pair: tuple, tool: str) -> bool:
    return tool in pair and any(name.startswith("block_") for name in pair)


def exclusion_smoke_test(saved: dict[str, np.ndarray]) -> dict:
    with (REFERENCE / "contacts.jsonl").open() as stream:
        candidates = [json.loads(line) for line in stream]
    candidates = [c for c in candidates if is_tool_block(c["bodies"], "brush")]
    strongest = max(candidates, key=lambda c: c["force"][0])
    step = round(strongest["time"] / 0.002)
    pairs = {}
    for name, disable in [("reference", False), ("negative_control", True)]:
        model = condition_model(disable, 1.0)
        data = mujoco.MjData(model)
        data.qpos[:] = saved["qpos"][step]
        data.qvel[:] = saved["qvel"][step]
        mujoco.mj_forward(model, data)
        pairs[name] = body_pairs(model, data)
    original = pairs["reference"]
    ablated = pairs["negative_control"]
    assert any(is_tool_block(pair, "brush") for pair in original)
    assert not any(is_tool_block(pair, "brush") for pair in ablated)
    remaining = sorted(pair for pair in original if not is_tool_block(pair, "brush"))
    assert remaining == sorted(ablated)
    report = {"passed": True, "reference_step": step,
              "reference_time_s": float(saved["time"][step]),
              "reference_pairs": original, "ablated_pairs": ablated,
              "non_target_contact_pairs_preserved": True}
    (OUTPUT / "contact-exclusion-smoke-test.json").write_text(json.dumps(report, indent=2))
    return report


def run_condition(condition: dict) -> dict:
    with np.load(REFERENCE / "trajectory.npz") as source:
        initial_qpos = source["qpos"][0].copy()
        initial_qvel = source["qvel"][0].copy()
        controls = source["ctrl"].copy()
        frame_steps = set(source["frame_indices"].tolist())
        reference_final = source["qpos"][-1].copy()
    model = condition_model(condition["disable_contact"], condition["friction_scale"])
    data = mujoco.MjData(model)
    offsets = np.random.default_rng(condition["seed"]).uniform(
        -condition["xy_jitter_m"], condition["xy_jitter_m"], (6, 2)
    )
    for index, offset in enumerate(offsets):
        address = model.jnt_qposadr[model.body(f"block_{index}").jntadr[0]]
        initial_qpos[address:address + 2] += offset
    data.qpos[:] = initial_qpos
    data.qvel[:] = initial_qvel
    mujoco.mj_forward(model, data)
    counts = {"brush_block": 0, "dustpan_block": 0}
    maximum_penetration = 0.0
    started = time.perf_counter()
    for step, control in enumerate(controls, 1):
        data.ctrl[:] = control
        mujoco.mj_step(model, data)
        for pair in body_pairs(model, data):
            for tool in ["brush", "dustpan"]:
                counts[f"{tool}_block"] += int(is_tool_block(pair, tool))
        maximum_penetration = max(maximum_penetration,
                                  max((-c.dist for c in data.contact), default=0.0))
        if step in frame_steps:
            mujoco.mj_forward(model, data)
    spec = json.loads((REFERENCE / "resolved-scene-spec.json").read_text())
    result = {"name": condition["name"], "role": condition["role"],
              "reference_run_id": json.loads((REFERENCE / "metrics.json").read_text())["run_id"],
              "ctrl_sha256": array_hash(controls), "ctrl_shape": list(controls.shape),
              "ctrl_replanned": False, "random_seed": condition["seed"],
              "block_xy_offsets_m": offsets.tolist(),
              "model_changes": {"brush_block_contact_disabled": condition["disable_contact"],
                                "block_sliding_friction_multiplier": condition["friction_scale"],
                                "compiler_threads": False},
              "cpu_affinity": sorted(os.sched_getaffinity(0)),
              "initial_qpos_sha256": array_hash(initial_qpos),
              "wall_seconds": time.perf_counter() - started,
              "contact_counts": counts, "max_penetration_m": maximum_penetration,
              "final_qpos": data.qpos.tolist(),
              "final_max_abs_difference_from_reference": float(abs(data.qpos - reference_final).max()),
              "task_metrics": task_metrics(model, data, spec)}
    (OUTPUT / f"{condition['name']}.json").write_text(json.dumps(result, indent=2))
    return result


def evidence_data(saved: dict[str, np.ndarray]) -> None:
    names = saved["body_names"].tolist()
    pan = names.index("dustpan")
    blocks = [names.index(f"block_{index}") for index in range(6)]
    pan_quat = saved["body_xquat"][:, pan][:, [1, 2, 3, 0]]
    pan_rotation = Rotation.from_quat(pan_quat).as_matrix()
    relative = saved["body_xpos"][:, blocks] - saved["body_xpos"][:, pan, None]
    local = np.einsum("fbi,fij->fbj", relative, pan_rotation)
    impulse = np.zeros(len(saved["ctrl"]))
    with (REFERENCE / "contacts.jsonl").open() as stream:
        for line in stream:
            contact = json.loads(line)
            if is_tool_block(contact["bodies"], "brush"):
                impulse[round(contact["time"] / 0.002)] += contact["force"][0] * 0.002
    np.savez_compressed(
        OUTPUT / "evidence-data.npz", time=saved["time"],
        cumulative_impulse=np.r_[0.0, np.cumsum(impulse)],
        frame_time=saved["time"][saved["frame_indices"]],
        block_local_y=local[:, :, 1],
    )


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    frozen = [REFERENCE / name for name in [
        "scene.xml", "trajectory.npz", "metrics.json",
        "resolved-scene-spec.json", "contacts.jsonl",
    ]]
    before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in frozen}
    with np.load(REFERENCE / "trajectory.npz") as source:
        saved = {name: source[name].copy() for name in source.files}
    smoke = exclusion_smoke_test(saved)
    print(f"Contact exclusion smoke test passed at step {smoke['reference_step']}", flush=True)
    conditions = [
        ("reference-replay", "reference", False, 1.0, 0.0, 0),
        ("no-brush-block-contact", "negative_control", True, 1.0, 0.0, 0),
        ("xy-jitter-seed11", "perturbation", False, 1.0, 0.003, 11),
        ("xy-jitter-seed29", "perturbation", False, 1.0, 0.003, 29),
        ("block-friction-plus20", "perturbation", False, 1.2, 0.0, 0),
    ]
    keys = ["name", "role", "disable_contact", "friction_scale", "xy_jitter_m", "seed"]
    with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(run_condition, [dict(zip(keys, item)) for item in conditions]))
    evidence_data(saved)
    after = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in frozen}
    assert before == after
    assert len({result["ctrl_sha256"] for result in results}) == 1
    assert results[0]["final_max_abs_difference_from_reference"] < 1e-9
    assert results[1]["contact_counts"]["brush_block"] == 0
    summary = {"reference_files_sha256": before, "frozen_files_unchanged": True,
               "total_runs": len(results), "max_worker_processes": 3,
               "blas_threads_per_process": 1, "smoke_test": smoke,
               "results": results}
    (OUTPUT / "validation-summary.json").write_text(json.dumps(summary, indent=2))
    for result in results:
        print(result["name"], result["task_metrics"]["blocks_in_dustpan"], flush=True)


if __name__ == "__main__":
    main()
