import os

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

import datetime
import hashlib
import json
import pathlib

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = pathlib.Path(__file__).resolve().parents[2]
REFERENCE = ROOT / "agent/out/simulation"
OUTPUT = ROOT / "agent/out/validation"


def audit_contact_input(data: dict[str, np.ndarray]) -> dict:
    timestep = float(data["time"][1] - data["time"][0])
    increments = np.zeros(len(data["time"]) - 1)
    digest = hashlib.sha256()
    with (REFERENCE / "contacts.jsonl").open("rb") as stream:
        for line in stream:
            digest.update(line)
            contact = json.loads(line)
            if "brush" in contact["bodies"] and any(
                name.startswith("block_") for name in contact["bodies"]
            ):
                increments[round(contact["time"] / timestep)] += (
                    contact["force"][0] * timestep
                )
    recomputed = np.r_[0.0, np.cumsum(increments)]
    maximum = float(abs(recomputed - data["cumulative_impulse"]).max())
    assert maximum < 1e-12
    return {"contacts_sha256": digest.hexdigest(),
            "hash_capture_phase": "post-run",
            "captured_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "cumulative_impulse_max_abs_difference_ns": maximum,
            "cumulative_impulse_verified_pointwise": True}


def style_axes(axis: plt.Axes) -> None:
    axis.spines[["top", "right"]].set_visible(False)
    axis.spines[["left", "bottom"]].set_color("#b9c5c5")
    axis.tick_params(colors="#435255", labelsize=10)
    axis.grid(axis="y", color="#e8eded", linewidth=0.8)
    axis.set_axisbelow(True)
    axis.set_xlim(0, 7.2)
    axis.set_xticks([0, 2, 4, 6])
    axis.set_xlabel("Time (s)", color="#344548", labelpad=8)


def draw_impulse(axis: plt.Axes, data: dict[str, np.ndarray]) -> None:
    time = data["time"]
    impulse = data["cumulative_impulse"]
    axis.fill_between(time, impulse, color="#dcefed")
    axis.plot(time, impulse, color="#237b7e", linewidth=2.8)
    axis.set_ylim(0, float(impulse[-1]) * 1.19)
    axis.set_ylabel("Cumulative normal impulse (N·s)", labelpad=10)
    axis.set_title("Brush → block contact", loc="left", pad=18,
                   fontsize=13, fontweight="bold", color="#183336")
    axis.annotate(f"{impulse[-1]:.3f} N·s", xy=(6.8, impulse[-1]),
                  xytext=(3.65, impulse[-1] * 1.085), fontsize=12,
                  color="#1a676a", fontweight="bold")
    style_axes(axis)


def draw_progress(axis: plt.Axes, data: dict[str, np.ndarray], spec: dict) -> None:
    colors = spec["blocks"]["colors"]
    axis.axhspan(0, spec["dustpan"]["depth"], color="#eef5ed", zorder=0)
    axis.axhline(0, color="#7e927e", linewidth=1.2, linestyle="--")
    axis.axhline(spec["dustpan"]["depth"], color="#aebbad", linewidth=0.8)
    for index in range(6):
        axis.plot(data["frame_time"], data["block_local_y"][:, index],
                  color=colors[index], linewidth=2.0,
                  linestyle="-" if index < 3 else "--", label=f"B{index + 1}")
    axis.set_ylim(-0.205, 0.252)
    axis.set_ylabel("Block-center y in dustpan frame (m)", labelpad=10)
    axis.set_title("Six conserved blocks", loc="left", pad=18,
                   fontsize=13, fontweight="bold", color="#183336")
    axis.text(0.15, 0.01, "Opening", color="#677c66", fontsize=9)
    axis.text(0.15, 0.237, "Rear wall", color="#677c66", fontsize=9)
    axis.legend(ncol=6, frameon=False, loc="lower center",
                bbox_to_anchor=(0.5, -0.35), fontsize=9, handlelength=1.6,
                columnspacing=1.25)
    style_axes(axis)


def draw_trial_counts(figure: plt.Figure, summary: dict) -> None:
    labels = ["Reference replay", "Brush–block contact OFF",
              "Block xy ±3 mm · seed 11", "Block xy ±3 mm · seed 29",
              "Block geom friction +20%"]
    for index, (label, result) in enumerate(zip(labels, summary["results"])):
        x = 0.076 + index * 0.184
        count = result["task_metrics"]["blocks_in_dustpan"]
        color = "#9f5328" if result["role"] == "negative_control" else "#204f53"
        figure.text(x, 0.143, label, fontsize=8.6, color="#596b6e")
        figure.text(x, 0.094, f"{count}/6", fontsize=17,
                    fontweight="bold", color=color)
    figure.text(0.076, 0.035,
                "Fixed controls in all five trials; three perturbations are a limited check. "
                "Counts use all eight cube corners with 1 mm floor-contact tolerance.",
                fontsize=8.3, color="#687b7e")


def main() -> None:
    with np.load(OUTPUT / "evidence-data.npz") as source:
        data = {name: source[name].copy() for name in source.files}
    summary = json.loads((OUTPUT / "validation-summary.json").read_text())
    spec = json.loads((REFERENCE / "resolved-scene-spec.json").read_text())
    audit = audit_contact_input(data)
    summary["additional_evidence_audit"] = audit
    (OUTPUT / "validation-summary.json").write_text(json.dumps(summary, indent=2))
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "svg.fonttype": "none", "axes.labelcolor": "#344548"})
    figure, axes = plt.subplots(1, 2, figsize=(12.8, 6.2),
                                gridspec_kw={"width_ratios": [1, 1.45]})
    figure.subplots_adjust(left=0.075, right=0.982, bottom=0.35,
                            top=0.77, wspace=0.28)
    figure.text(0.075, 0.94, "Fixed-control physics evidence", fontsize=23,
                fontweight="bold", color="#183336")
    figure.text(0.075, 0.884,
                "Frozen TIAGo++ rollout · six free blocks · contact-driven motion",
                fontsize=12, color="#61777a")
    draw_impulse(axes[0], data)
    draw_progress(axes[1], data, spec)
    draw_trial_counts(figure, summary)
    figure.savefig(OUTPUT / "physics-evidence.png", dpi=200, facecolor="white")
    figure.savefig(OUTPUT / "physics-evidence.svg", facecolor="white")
    plt.close(figure)
    (OUTPUT / "figure-provenance.json").write_text(json.dumps({
        "reference_run_id": summary["results"][0]["reference_run_id"],
        "reference_ctrl_sha256": summary["results"][0]["ctrl_sha256"],
        "contact_audit": audit,
        "curves": "Frozen reference rollout only; trial counts shown separately",
        "friction_condition": "Block geom sliding friction parameter multiplied by 1.2",
        "collection_rule": "All 8 corners within cavity, with 1 mm floor-contact tolerance",
    }, indent=2))


if __name__ == "__main__":
    main()
