import json
from pathlib import Path

import bpy
import numpy as np

root = Path(__file__).resolve().parents[2]
trajectory = np.load(root / "agent/out/simulation/trajectory.npz")
scene = bpy.context.scene
assert (scene.frame_start, scene.frame_end, scene.render.fps) == (0,173,24)
assert all(bpy.data.objects[name].type == "CAMERA" for name in ["global","ego","gripper"])
assert not any(c.type == "TRANSFORM_CACHE" for obj in scene.objects for c in obj.constraints)
assert not any(m.type == "MESH_SEQUENCE_CACHE" for obj in scene.objects for m in obj.modifiers)
assert not any(cache.users for cache in bpy.data.cache_files)
assert not any(image.users and image.source == "FILE" and not image.packed_file for image in bpy.data.images)
errors = []
for frame in [0,87,173]:
    scene.frame_set(frame)
    for name in ["dustpan","brush"]:
        index = list(trajectory["body_names"]).index(name)
        obj = bpy.data.objects[f"{name}_visual"]
        errors.append(float(np.max(np.abs(np.array(obj.matrix_world.translation)-trajectory["body_xpos"][frame,index]))))
assert max(errors) < 1e-6
report={"self_contained":True,"dynamic_usd_references":0,"tool_position_max_error":max(errors),
        "cameras":["global","ego","gripper"],"frames":174,"fps":24}
(root/"agent/out/blend-validation.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report))
