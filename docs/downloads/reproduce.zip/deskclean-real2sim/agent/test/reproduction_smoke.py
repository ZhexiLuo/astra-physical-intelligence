import hashlib
import importlib.metadata
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

import numpy as np


ROOT = pathlib.Path(__file__).resolve().parents[2]
FROZEN = ["scene.xml", "trajectory.npz", "metrics.json",
          "resolved-scene-spec.json", "contacts.jsonl"]


def digest(path: pathlib.Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    started = time.monotonic()
    reference = ROOT / "agent/out/simulation"
    before = {name: digest(reference / name) for name in FROZEN}
    run = ROOT / "agent/out/reproduction-smoke"
    run.mkdir()
    (run / "agent/out").mkdir(parents=True)
    (run / "agent/test").mkdir(parents=True)
    for directory in ["src", "thirdparty"]:
        shutil.copytree(ROOT / directory, run / directory,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for name in ["simulation_contract.py", "check_blend.py"]:
        shutil.copyfile(ROOT / "agent/test" / name, run / "agent/test" / name)
    shutil.copyfile(ROOT / "agent/out/scene_spec.json", run / "agent/out/scene_spec.json")
    environment = dict(os.environ, DESKCLEAN_ROOT=str(run))
    print(json.dumps({"run_root": str(run), "python": sys.executable,
                      "cpu_affinity": sorted(os.sched_getaffinity(0)),
                      "threads": {name: environment[name] for name in
                                  ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]},
                      "versions": {name: importlib.metadata.version(name) for name in
                                   ["mujoco", "numpy", "scipy", "usd-core", "pillow", "imageio-ffmpeg"]},
                      "reference_sha256_before": before}, indent=2), flush=True)
    for arguments in [["-m", "src.simulation"], ["-m", "unittest", "agent.test.simulation_contract"]]:
        print("Command: " + " ".join([sys.executable, *arguments]), flush=True)
        subprocess.run([sys.executable, *arguments], cwd=run, env=environment, check=True)
    after = {name: digest(reference / name) for name in FROZEN}
    assert before == after
    output = run / "agent/out/simulation"
    with np.load(reference / "trajectory.npz") as original, np.load(output / "trajectory.npz") as rerun:
        errors = {name: float(np.max(np.abs(original[name] - rerun[name])))
                  for name in ["qpos", "qvel", "ctrl"]}
    assert all(error == 0.0 for error in errors.values())
    result = json.loads((output / "metrics.json").read_text())
    assert result["success"] is True
    report = {"run_root": str(run), "success": result["success"],
              "blocks_in_dustpan": result["blocks_in_dustpan"],
              "validity_checks": result["validity_checks"],
              "replay_max_abs_qpos_error": result["replay_max_abs_qpos_error"],
              "reference_trajectory_max_abs_error": errors,
              "reference_sha256_before": before, "reference_sha256_after": after,
              "elapsed_seconds": time.monotonic() - started}
    (ROOT / "agent/out/reproduction-smoke-result.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
