import datetime
import inspect
import json
import pathlib
import unittest

import mujoco
import numpy as np

from src import simulation


class SimulationContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.root = pathlib.Path(__file__).resolve().parents[2]
        cls.output = cls.root / "agent/out/simulation"
        cls.result = json.loads((cls.output / "metrics.json").read_text())
        cls.checks = {name: False for name in [
            "physical_task", "independent_control_replay", "state_contract",
            "control_only_runtime", "original_force_limits",
        ]}

    @classmethod
    def tearDownClass(cls) -> None:
        cls.result["validity_checks"] = cls.checks
        cls.result["success"] = all(cls.checks.values())
        cls.result["run_id"] = datetime.datetime.now(datetime.timezone.utc).strftime(
            "tiago-deskclean-%Y%m%dT%H%M%SZ"
        )
        (cls.output / "metrics.json").write_text(json.dumps(cls.result, indent=2))

    def test_conserved_blocks_reach_dustpan(self) -> None:
        self.assertEqual(self.result["block_count"], 6)
        self.assertEqual(self.result["blocks_in_dustpan"], 6)
        self.assertGreater(self.result["brush_block_contacts"], 0)
        self.assertGreater(self.result["dustpan_block_contacts"], 0)
        self.assertEqual(self.result["warnings"], {})
        self.assertLess(self.result["ik_max_position_error"], 0.001)
        self.assertLess(self.result["max_penetration_m"]["block_dustpan"], 0.0015)
        self.assertLess(self.result["max_penetration_m"]["robot_self"], 0.001)
        self.checks["physical_task"] = True

    def test_independent_control_replay(self) -> None:
        error = simulation.replay_controls(
            self.output / "scene.xml", self.output / "trajectory.npz"
        )
        self.assertLess(error, 1e-9)
        self.result["replay_max_abs_qpos_error"] = error
        self.checks["independent_control_replay"] = True

    def test_scene_and_saved_state_contract(self) -> None:
        model = mujoco.MjModel.from_xml_path(str(self.output / "scene.xml"))
        self.assertEqual(model.nmocap, 0)
        self.assertEqual(model.body("base_link").jntnum, 0)
        for index in range(6):
            joint = model.body(f"block_{index}").jntadr[0]
            self.assertEqual(model.jnt_type[joint], mujoco.mjtJoint.mjJNT_FREE)
        with np.load(self.output / "trajectory.npz") as data:
            self.assertEqual(len(data["qpos"]), len(data["ctrl"]) + 1)
            self.assertEqual(data["body_xquat"].shape[-1], 4)
            self.assertTrue(np.isfinite(data["qvel"]).all())
        self.assertTrue((self.output / "contacts.jsonl").stat().st_size)
        self.checks["state_contract"] = True

    def test_runtime_writes_only_control(self) -> None:
        source = inspect.getsource(simulation.step_control)
        for forbidden in ["qpos[", "qvel[", "mocap", "xfrc_applied", "qfrc_applied"]:
            self.assertNotIn(forbidden, source)
        self.assertIn("mj_step", source)
        self.checks["control_only_runtime"] = True

    def test_original_force_limits(self) -> None:
        assets = self.root / "thirdparty/mujoco_menagerie/pal_tiago_dual"
        original = mujoco.MjModel.from_xml_path(str(assets / "scene_position.xml"))
        actual = mujoco.MjModel.from_xml_path(str(self.output / "scene.xml"))
        for index in range(actual.nu):
            name = actual.actuator(index).name
            np.testing.assert_array_equal(actual.actuator(name).forcerange,
                                          original.actuator(name).forcerange)
            joint_name = actual.joint(actual.actuator_trnid[index, 0]).name
            joint, source = actual.joint(joint_name), original.joint(joint_name)
            np.testing.assert_array_equal(actual.jnt_actfrcrange[joint.id],
                                          original.jnt_actfrcrange[source.id])
            self.assertEqual(actual.jnt_actfrclimited[joint.id],
                             original.jnt_actfrclimited[source.id])
        self.checks["original_force_limits"] = True


if __name__ == "__main__":
    unittest.main()
