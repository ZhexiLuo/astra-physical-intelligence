import json
import runpy
from pathlib import Path

import bpy

root = Path(__file__).resolve().parents[2]
code = runpy.run_path(str(root / "src/create_assets.py"))
code["build_assets"]()
shell = bpy.data.objects["dustpan_shell"]
lip = [vertex for vertex in shell.data.vertices if abs(vertex.co.y) < 1e-6]
assert len(lip) >= 25
assert max(vertex.co.z for vertex in lip) < .004
assert max(vertex.co.y for vertex in shell.data.vertices) > .22
edges = {}
for polygon in shell.data.polygons:
    indices = list(polygon.vertices)
    for a, b in zip(indices, indices[1:] + indices[:1]):
        edges.setdefault(tuple(sorted((a, b))), []).append((a, b))
assert all(pairs[0] == pairs[1][::-1] for pairs in edges.values() if len(pairs) == 2)
assert bpy.data.objects["brush_filaments"].parent.name == "brush_visual"
assert len(bpy.data.objects["brush_filaments"].data.vertices) == 52 * 12 * 10
assert (root / "agent/out/assets/tools.blend").stat().st_size > 1000
print("ASSET CONTRACT TESTS PASSED")
