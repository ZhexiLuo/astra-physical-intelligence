import json
import os
import runpy
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


class BlenderControlTest(unittest.TestCase):
    def test_command_runs_once_per_atomic_update(self) -> None:
        script = Path(__file__).parents[1] / "scripts" / "blender_control.py"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            command = root / "command.py"
            command.write_text("bpy.executions.append('first')\n")
            registrations = []
            bpy = SimpleNamespace(
                executions=[],
                context=SimpleNamespace(window_manager=SimpleNamespace(windows=[])),
                app=SimpleNamespace(timers=SimpleNamespace(
                    register=lambda fn, **kwargs: registrations.append((fn, kwargs))
                )),
            )
            with patch.dict(sys.modules, bpy=bpy), patch.dict(
                os.environ, DESKCLEAN_CONTROL_DIR=directory
            ):
                runpy.run_path(str(script))
                poll, options = registrations[0]
                self.assertTrue(options["persistent"])
                self.assertEqual(poll(), 0.5)
                poll()
                self.assertEqual(bpy.executions, ["first"])
                replacement = root / "command.pending.py"
                replacement.write_text("bpy.executions.append('second')\n")
                os.utime(replacement, ns=(command.stat().st_mtime_ns + 1,) * 2)
                replacement.replace(command)
                poll()
                self.assertEqual(bpy.executions, ["first", "second"])
                status = json.loads((root / "status.json").read_text())
                self.assertEqual(status["state"], "done")
                self.assertEqual(status["command_mtime_ns"], command.stat().st_mtime_ns)


if __name__ == "__main__":
    unittest.main()
