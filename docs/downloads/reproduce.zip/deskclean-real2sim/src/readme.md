# Pipeline modules

`simulation.py` builds the MJCF, executes the skill, and records physical states.
`robot_control.py` solves tool poses and produces actuator targets.
`create_assets.py` builds source-based Blender tools.
`export_usd.py` uses the official MuJoCo USD exporter.
`blender_scene.py` defines stage materials and lighting; `import_replay.py` bakes
the recorded rigid-body motion and mounts three cameras. `render.py` renders PNGs.

Run `bash scripts/reproduce.sh` from the project root. See the root README for the
required assets, environment, and output paths.
