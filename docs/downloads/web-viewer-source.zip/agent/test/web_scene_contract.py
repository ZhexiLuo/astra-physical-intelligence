import argparse
import hashlib
import itertools
import json
import struct
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils.kdtree import KDTree


def mesh_points(obj: bpy.types.Object) -> tuple[np.ndarray, np.ndarray]:
    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = evaluated.to_mesh()
    mesh.calc_loop_triangles()
    points = np.array([evaluated.matrix_world @ vertex.co for vertex in mesh.vertices])
    indices = np.array([triangle.vertices[:] for triangle in mesh.loop_triangles])
    evaluated.to_mesh_clear()
    return points, indices


def capture_transforms(names: list[str], frames: list[int]) -> np.ndarray:
    matrices = []
    for frame in frames:
        bpy.context.scene.frame_set(frame)
        matrices.append([np.array(bpy.data.objects[name].matrix_world) for name in names])
    return np.array(matrices)


def point_set_error(first: np.ndarray, second: np.ndarray) -> float:
    tree = KDTree(len(second))
    for index, point in enumerate(second):
        tree.insert(point, index)
    tree.balance()
    return max(tree.find(point)[2] for point in first)


def triangle_match_error(first: tuple, second: tuple) -> float:
    points, faces = first
    other_points, other_faces = second
    triangles, candidates = points[faces], other_points[other_faces]
    centers, other_centers = triangles.mean(axis=1), candidates.mean(axis=1)
    tree = KDTree(len(other_centers))
    for index, center in enumerate(other_centers):
        tree.insert(center, index)
    tree.balance()
    nearest = np.array([tree.find(center)[1] for center in centers])
    permutations = np.array(list(itertools.permutations(range(3))))
    delta = triangles[:, None] - candidates[nearest][:, permutations]
    errors = np.linalg.norm(delta, axis=-1).max(axis=-1).min(axis=-1)
    for index, center in enumerate(centers):
        nearby = [item[1] for item in tree.find_range(center, 5e-5)]
        if len(nearby) > 1:
            delta = triangles[index] - candidates[nearby][:, permutations]
            errors[index] = np.linalg.norm(delta, axis=-1).max(axis=-1).min()
    return float(errors.max())


def unique_triangle_count(points: np.ndarray, faces: np.ndarray) -> int:
    indices = np.unique(points, axis=0, return_inverse=True)[1]
    return len(np.unique(np.sort(indices[faces], axis=1), axis=0))


def compare_geometry(original: tuple, imported: tuple, name: str) -> dict:
    points, faces = original
    other_points, other_faces = imported
    error = max(point_set_error(points, other_points), point_set_error(other_points, points))
    surface_error = max(triangle_match_error(original, imported), triangle_match_error(imported, original))
    assert error < 5e-5, (name, error)
    assert surface_error < 5e-5, (name, surface_error)
    return {"world_vertex_set_max_distance_m": error,
            "matched_triangle_corner_max_distance_m": surface_error,
            "source_triangles": len(faces), "imported_triangles": len(other_faces),
            "source_unique_triangles": unique_triangle_count(points, faces),
            "imported_unique_triangles": unique_triangle_count(other_points, other_faces)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--blend", type=Path, required=True)
    parser.add_argument("--glb", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    binary = args.glb.read_bytes()
    length, chunk_type = struct.unpack_from("<II", binary, 12)
    assert chunk_type == 0x4E4F534A
    document = json.loads(binary[20:20 + length])
    assert len(document["animations"]) == 1
    source_hash = hashlib.sha256(args.blend.read_bytes()).hexdigest()
    bpy.ops.wm.open_mainfile(filepath=str(args.blend))
    scene = bpy.context.scene
    frames = list(range(scene.frame_start, scene.frame_end + 1))
    fps = scene.render.fps
    names = sorted(obj.name for obj in scene.objects if obj.type == "MESH")
    before = capture_transforms(names, frames)
    scene.frame_set(0)
    geometry = {name: mesh_points(bpy.data.objects[name]) for name in names}
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.scene.render.fps = fps
    bpy.ops.import_scene.gltf(filepath=str(args.glb))
    imported_names = sorted(obj.name for obj in bpy.context.scene.objects if obj.type == "MESH")
    assert names == imported_names
    after = capture_transforms(names, frames)
    matrix_error = float(abs(before - after).max())
    index = np.unravel_index(np.argmax(abs(before - after)), before.shape)
    assert matrix_error < 2e-5, (matrix_error, names[index[1]], int(index[0]))
    bpy.context.scene.frame_set(0)
    geometry_audit = {}
    for name in names:
        geometry_audit[name] = compare_geometry(geometry[name], mesh_points(bpy.data.objects[name]), name)
    for node in document["nodes"]:
        if node.get("name") in geometry_audit and "mesh" in node:
            geometry_audit[node["name"]]["glb_triangles"] = sum(
                document["accessors"][primitive["indices"]]["count"] // 3
                for primitive in document["meshes"][node["mesh"]]["primitives"])
    assert all("uri" not in value for value in document["buffers"])
    assert all("uri" not in value for value in document.get("images", []))
    assert len(binary) <= 20_000_000
    assert hashlib.sha256(args.blend.read_bytes()).hexdigest() == source_hash
    report = {"passed": True, "source_blend_sha256": source_hash,
              "glb_sha256": hashlib.sha256(binary).hexdigest(), "size_bytes": len(binary),
              "mesh_count": len(names), "frames_checked": len(frames), "fps": fps,
              "animation_count": len(document["animations"]),
              "animation_names": [item["name"] for item in document["animations"]],
              "matrix_max_abs_error": matrix_error,
              "world_vertex_set_max_distance_m": max(
                  item["world_vertex_set_max_distance_m"] for item in geometry_audit.values()),
              "matched_triangle_corner_max_distance_m": max(
                  item["matched_triangle_corner_max_distance_m"] for item in geometry_audit.values()),
              "geometry_tolerance_m": 5e-5, "matrix_tolerance": 2e-5,
              "surface_comparison": "Every triangle is matched by centroid proximity and all 6 corner permutations in both directions, at frame 0; maximum corresponding-corner distance bounds each matched surface pair",
              "raw_triangle_counts_identical": all(item["source_triangles"] == item["imported_triangles"]
                                                    for item in geometry_audit.values()),
              "external_asset_uris": 0, "source_blend_unchanged": True,
              "geometry_note": "Duplicate faces in source meshes are cleaned by the official glTF pipeline. Raw and unique triangle counts are reported per mesh.",
              "geometry_audit": geometry_audit}
    args.output.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
